from fastapi import APIRouter, HTTPException
import os

from app.metrics.metrics_service import calculate_file_metrics


router = APIRouter(
    prefix="/metrics",
    tags=["Software Metrics"]
)


@router.get("/{project_id}")
def get_metrics(project_id: str):

    project_path = os.path.join(
        "uploads",
        project_id
    )

    if not os.path.exists(project_path):
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    results = []

    for root, dirs, files in os.walk(project_path):

        for file in files:

            if file.endswith(".java"):

                file_path = os.path.join(
                    root,
                    file
                )

                metrics = calculate_file_metrics(
                    file_path
                )

                results.append(metrics)

    return results