from fastapi import APIRouter, HTTPException
import os

from app.parser.parser_service import scan_project
from app.analyzer.dependency_analyzer import extract_dependencies
from app.knowledge_graph.graph_service import create_project_graph


router = APIRouter(
    prefix="/graph",
    tags=["Knowledge Graph"]
)


@router.post("/{project_id}")
def generate_graph(project_id: str):

    project_path = os.path.join(
        "uploads",
        project_id
    )

    if not os.path.exists(project_path):
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    # 1. Parse project
    parsed_files = scan_project(project_path)

    # 2. Extract dependencies
    dependencies = extract_dependencies(
        parsed_files
    )

    if not dependencies:
        raise HTTPException(
            status_code=404,
            detail="No dependencies found"
        )

    # 3. Create Neo4j graph
    result = create_project_graph(
        project_id,
        dependencies
    )

    return result