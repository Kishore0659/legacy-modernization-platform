from fastapi import APIRouter, HTTPException
import os

from app.parser.parser_service import scan_project
from app.analyzer.dependency_analyzer import extract_dependencies
from app.agents.graph import build_agent_graph


router = APIRouter(
    prefix="/ai",
    tags=["AI Analysis"]
)


@router.get("/analyze/{project_id}")
def analyze_project(project_id: str):

    project_path = os.path.join(
        "uploads",
        project_id
    )

    if not os.path.exists(project_path):
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    parsed_files = scan_project(project_path)

    dependencies = extract_dependencies(
        parsed_files
    )

    graph = build_agent_graph()

    result = graph.invoke({
        "project_id": project_id,
        "parsed_files": parsed_files,
        "dependencies": dependencies
    })

    return {
    "project_id": project_id,
    "code_analysis": result.get("code_analysis", []),
    "security_analysis": result.get("security_analysis", []),
    "documentation": result.get("documentation", []),
    "tests": result.get("tests", []),
    "modernization": result.get("modernization", [])
}