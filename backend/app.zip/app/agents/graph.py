from langgraph.graph import StateGraph, START, END

from app.agents.state import AgentState
from app.agents.code_agent import code_understanding_agent
from app.agents.security_agent import security_agent
from app.agents.documentation_agent import documentation_agent
from app.agents.testing_agent import testing_agent
from app.agents.modernization_agent import modernization_agent


def build_agent_graph():

    graph = StateGraph(AgentState)

    # Agents
    graph.add_node(
        "code_agent",
        code_understanding_agent
    )

    graph.add_node(
        "security_agent",
        security_agent
    )

    graph.add_node(
        "documentation_agent",
        documentation_agent
    )

    graph.add_node(
        "testing_agent",
        testing_agent
    )

    graph.add_node(
        "modernization_agent",
        modernization_agent
    )

    # Workflow
    graph.add_edge(
        START,
        "code_agent"
    )

    graph.add_edge(
        "code_agent",
        "security_agent"
    )

    graph.add_edge(
        "security_agent",
        "documentation_agent"
    )

    graph.add_edge(
        "documentation_agent",
        "testing_agent"
    )

    graph.add_edge(
        "testing_agent",
        "modernization_agent"
    )

    graph.add_edge(
        "modernization_agent",
        END
    )

    return graph.compile()