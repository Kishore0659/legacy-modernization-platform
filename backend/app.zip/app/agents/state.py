from typing import TypedDict, Any


class AgentState(TypedDict, total=False):

    project_id: str

    parsed_files: list

    dependencies: list

    metrics: list

    code_analysis: list

    security_analysis: list

    documentation: list

    tests: list

    modernization: list

    cloud_recommendations: list

    final_report: dict