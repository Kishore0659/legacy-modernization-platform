def code_understanding_agent(state):

    parsed_files = state.get("parsed_files", [])

    analysis = []

    for file_data in parsed_files:

        file_analysis = file_data.get("analysis", {})

        classes = file_analysis.get("classes", [])

        class_details = []

        for cls in classes:

            methods = cls.get("methods", [])

            class_details.append({
                "name": cls.get("name"),
                "extends": cls.get("extends"),
                "implements": cls.get("implements", []),
                "fields": cls.get("fields", []),
                "constructors": cls.get("constructors", []),
                "method_count": len(methods),
                "methods": [
                    {
                        "name": method.get("name"),
                        "return_type": method.get("return_type"),
                        "parameters": method.get("parameters", []),
                        "calls": method.get("calls", [])
                    }
                    for method in methods
                ]
            })

        analysis.append({
            "file": file_data.get("file"),
            "language": file_analysis.get("language"),
            "package": file_analysis.get("package"),
            "imports": file_analysis.get("imports", []),
            "classes": class_details
        })

    state["code_analysis"] = analysis

    return state