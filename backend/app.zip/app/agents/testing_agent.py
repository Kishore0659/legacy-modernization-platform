def testing_agent(state):

    code_analysis = state.get("code_analysis", [])

    tests = []

    for file_data in code_analysis:

        for cls in file_data.get("classes", []):

            class_name = cls.get("name")

            for method in cls.get("methods", []):

                method_name = method.get("name")

                tests.append({
                    "file": file_data.get("file"),
                    "class": class_name,
                    "method": method_name,
                    "test_name": f"test_{method_name}",
                    "test_type": "unit",
                    "suggestion": (
                        f"Create a unit test for "
                        f"{class_name}.{method_name}()"
                    )
                })

    state["tests"] = tests

    return state