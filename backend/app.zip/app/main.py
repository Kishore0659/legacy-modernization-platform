from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.upload import router as upload_router
from app.api.parser import router as parser_router
from app.api.dependencies import router as dependencies_router
from app.knowledge_graph.neo4j_client import test_connection
from app.api.knowledge_graph import router as graph_router
from app.api.metrics import router as metrics_router
from app.api.agents import router as agents_router

app = FastAPI(
    title="AI Legacy Modernization Platform",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload_router)
app.include_router(parser_router)
app.include_router(dependencies_router)
app.include_router(graph_router)
app.include_router(metrics_router)
app.include_router(
    agents_router
)

@app.get("/neo4j-test")
def neo4j_test():
    return {
        "status": test_connection()
    }

@app.get("/")
def home():
    return {
        "message": "AI Legacy Modernization Platform Backend Running"
    }